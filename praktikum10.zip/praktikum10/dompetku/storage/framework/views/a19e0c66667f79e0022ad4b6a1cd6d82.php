<?php use \Illuminate\Support\Carbon; ?>


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 class="text-sm font-medium text-gray-500 uppercase tracking-wider">Total Saldo</h3>
        <p class="mt-2 text-3xl font-bold text-gray-900">Rp <?php echo e(number_format($saldo, 0, ',', '.')); ?></p>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 class="text-sm font-medium text-emerald-500 uppercase tracking-wider">Pemasukan</h3>
        <p class="mt-2 text-3xl font-bold text-emerald-600">+ Rp <?php echo e(number_format($pemasukan, 0, ',', '.')); ?></p>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 class="text-sm font-medium text-rose-500 uppercase tracking-wider">Pengeluaran</h3>
        <p class="mt-2 text-3xl font-bold text-rose-600">- Rp <?php echo e(number_format($pengeluaran, 0, ',', '.')); ?></p>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
        <h2 class="text-lg font-semibold text-gray-800">Riwayat Transaksi Terakhir</h2>
        <a href="<?php echo e(url('/transaksi/create')); ?>" class="text-sm text-indigo-600 font-medium hover:underline">Tambah Baru</a>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-50 text-gray-600 text-sm">
                    <th class="px-6 py-3 font-medium">Tanggal</th>
                    <th class="px-6 py-3 font-medium">Keterangan</th>
                    <th class="px-6 py-3 font-medium">Jenis</th>
                    <th class="px-6 py-3 font-medium text-right">Nominal</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__currentLoopData = $dataTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 text-sm text-gray-500">
                    <?php echo e(Carbon::parse($item['tanggal'])->translatedFormat('d F Y')); ?>

                        </td>
                    <td class="px-6 py-4 text-sm font-medium text-gray-900"><?php echo e($item['keterangan']); ?></td>
                    <td class="px-6 py-4 text-sm">
                        <?php if($item['jenis'] == 'pemasukan'): ?>
                            <span class="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-semibold">Pemasukan</span>
                        <?php else: ?>
                            <span class="px-2 py-1 bg-rose-100 text-rose-700 rounded-full text-xs font-semibold">Pengeluaran</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-sm font-bold text-right <?php echo e($item['jenis'] == 'pemasukan' ? 'text-emerald-600' : 'text-rose-600'); ?>">
                        Rp <?php echo e(number_format($item['nominal'], 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pwl_0213\praktikum10\dompetku\resources\views/transaksi/index.blade.php ENDPATH**/ ?>