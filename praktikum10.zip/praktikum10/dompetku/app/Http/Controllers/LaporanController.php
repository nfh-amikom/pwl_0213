<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LaporanController extends Controller
{
    public function index() {
        $transaksi = [
            [
                'id' => 1,
                'keterangan' => 'Gaji Bulanan',
                'nominal' => 5000000,
                'jenis' => 'pemasukan',
                'tanggal' => '2023-10-01'
            ],
            [
                'id' => 2,
                'keterangan' => 'Bayar Listrik',
                'nominal' => 350000,
                'jenis' => 'pengeluaran',
                'tanggal' => '2023-10-05'
            ],
            [
                'id' => 3,
                'keterangan' => 'Nabung',
                'nominal' => 25000,
                'jenis' => 'pengeluaran',
                'tanggal' => '2023-10-06'
            ],
        ];

        // Hitung total saldo sederhana
        $totalPemasukan = 5000000;
        $totalPengeluaran = 375000;
        $saldo = $totalPemasukan - $totalPengeluaran;

        return view('laporan.index', [
            'dataTransaksi' => $transaksi,
            'saldo' => $saldo,
            'pemasukan' => $totalPemasukan,
            'pengeluaran' => $totalPengeluaran,
        ]);
    }
}
